# Exploiting hash collisions

![](https://img.youtube.com/vi/Y-oJWEYKVLA/0.jpg)

- [video on Youtube](https://www.youtube.com/watch?v=Y-oJWEYKVLA)
- [slides on SpeakerDeck](https://speakerdeck.com/ange/exploiting-hash-collisions)
