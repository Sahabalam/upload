# Content of tables

- Y: yes
- W: yes, with warnings (Adobe asks to save when closing, Firefox shows a warning)
- E: empty page only (opens but unexpectedly without any displayed content)
- N: not working
